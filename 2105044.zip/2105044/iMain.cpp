# include "iGraphics.h"
#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>

#define width 1000
#define height 600

int time_i, time_f;
int random_number,check;
char question_source[5][100]={"hscmath.txt","physics.txt","cp.txt"};

struct  mcq
{
    char level[1000];
    char question[10000];
    char opt1[1000];
    char opt2[1000];
    char opt3[1000];
    char opt4[1000];
} ;
struct mcq mcq[9];
int correct_answer[9];
int option;
char halloffame[100]="\0";//name store & show


//for mode -1 buet cse logo co-ordinates bcx,bcy;
int bcx=0,bcy=8;
int dx=6,dy=7;
bool state=0;
int music=-1;


int t1,t2;

char strscore[100];
char strhighscore[100];

int a=10;

double load=0;
int loadcolor=30;

int question_number=0;
int score=0;
int highscore=0;
//text input
char str[100][100], str2[100];
int len=0;
int index=0;

char instruction[1000]="LEFT MOUSE BUTTON>>CHOOSE YOUR OPTION.";
char instruction2[1000]="CLICK ANYWHERE>>CONTINUE";

int r1,r2,r3,r4,g1,g2,g3,g4,b1,b2,b3,b4;

char bg[10][100]={"bg//quiz.bmp","bg//quiz.option","bg//quiz.question"};



int mode=0;


/*
	function iDraw() is called again and again by the system.

	*/

void iDraw() {





    //opening interface
    if(mode==0)
    {
    iClear();


    iSetColor(r1,g2,b3);
    iFilledRectangle(0,0,1000,600);
	iShowBMP(90,200,"quiz.bmp");
	iShowBMP(25,0,"option.bmp");
	iSetColor(r1,g1,b1);
    iText(200,200,"START",GLUT_BITMAP_TIMES_ROMAN_24);
    iSetColor(r2,g2,b2);
    iText(650,200,"INSTRUCTION",GLUT_BITMAP_TIMES_ROMAN_24);
    iSetColor(r3,g3,b3);
    iText(175,75,"HIGH SCORE",GLUT_BITMAP_TIMES_ROMAN_24);
    iSetColor(r4,g4,b4);
    iText(700,75,"EXIT",GLUT_BITMAP_TIMES_ROMAN_24);
    iSetColor(0,0,0);
    iText(800,10,"about game",GLUT_BITMAP_TIMES_ROMAN_24);

    //iLine(0,250,1000,250);
    //iLine(0,140,1000,140);
    //iLine(480,0,480,250);
    }
    else if(mode==-1)
    {
        iClear();

        iShowBMP(bcx,bcy,"buet_cselogo.bmp");
        iSetColor(36,230,224);
        //iFilledRectangle(0,0,1000,600);
        iText(380,330,"Niloy Kumar Mondal",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(380,300,"Roll : 2105044",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(380,270,"Level 1 Term 1 Project",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(380,240,"Quiz game :",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(500,240,"Rapid fire",GLUT_BITMAP_TIMES_ROMAN_24);

        iFilledRectangle(800,50,150,50);
        iSetColor(0,0,0);
        iText(840,65,"BACK",GLUT_BITMAP_TIMES_ROMAN_24);




    }
    else if(mode==1)
    {
        iClear();
        iSetColor(100,252,255);
        iFilledRectangle(0,0,1000,600);
        iSetColor(255,102,255);
        iFilledRectangle(730,50,170,50);
        iSetColor(0,0,0);
        iText(100,400,instruction,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(100,300,instruction2,GLUT_BITMAP_TIMES_ROMAN_24);
        //iText(400,400,a);
        iSetColor(255,0,0);
        iText(100,375,"Correct>>Score (Easy +10)(Medium +20)(Hard +30)",GLUT_BITMAP_TIMES_ROMAN_24);

        iText(100,350,"Wrong>>Score -10",GLUT_BITMAP_TIMES_ROMAN_24);


        iSetColor(0,0,0);
        iText(770,70,"B A C K",GLUT_BITMAP_TIMES_ROMAN_24);
    }
    else if(mode==2)
    {
        iClear();
        time_f = time(NULL);
        iShowBMP(15,100,"question.bmp");


        //iLine(0,320,1000,320);
        //iLine(0,210,1000,210);
        //iLine(0,100,1000,100);
        //iLine(490,100,490,320);
        //iLine(0,460,1000,460);

        iSetColor(33,231,238);
        iText(150,460,mcq[question_number].level,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(250,460,"//",GLUT_BITMAP_TIMES_ROMAN_24);

        iSetColor(255,255,0);
        iText(270,460,mcq[question_number].question,GLUT_BITMAP_TIMES_ROMAN_24);

        iText(160,270,mcq[question_number].opt1,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(650,270,mcq[question_number].opt2,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(160,140,mcq[question_number].opt3,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(650,140,mcq[question_number].opt4,GLUT_BITMAP_TIMES_ROMAN_24);

        iSetColor(255,0,0);

       // if(music==1)
        //{
          //  music=0;
        //}

        iSetColor(loadcolor,0,0);
        iFilledRectangle(0,50,load,50);

        //iText(15,50,"PRESS RIGHT MOUSE BUTTON TO CONTINUE",GLUT_BITMAP_TIMES_ROMAN_24);

    }

    else if(mode==3)
    {


        if(state)
        {
        iClear();
        iSetColor(0,255,0);
        iFilledRectangle(0,0,1000,600);
        iShowBMP(300,200,"correct.bmp");
        iSetColor(0,0,0);
        iFilledRectangle(300,20,350,150);
        iSetColor(73,733,206);
        iText(400,140,"CORRECT",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(400,90,"Current score :",GLUT_BITMAP_TIMES_ROMAN_24);
        iText(550,90,strscore,GLUT_BITMAP_TIMES_ROMAN_24);

        iText(50,100,strscore);


        iSetColor(0,0,0);
        iText(10,20,"PRESS ANYWHERE TO CONTINUE");

        }
        else if(!state)
        {
            iClear();
            iSetColor(255,0,0);
            iFilledRectangle(0,0,1000,600);
            iShowBMP(300,200,"wrong.bmp");
            iSetColor(0,0,0);
            iFilledRectangle(300,20,350,150);
            iSetColor(73,733,206);
            iText(400,140,"WRONG",GLUT_BITMAP_TIMES_ROMAN_24);
            iText(400,90,"Current score :",GLUT_BITMAP_TIMES_ROMAN_24);
            iText(550,90,strscore,GLUT_BITMAP_TIMES_ROMAN_24);

        iSetColor(0,0,0);
        iText(10,20,"PRESS ANYWHERE TO CONTINUE");



        }


    }

   else if(mode==4)
    {
          iClear();
          iSetColor(45,247,234);
          iFilledRectangle(300,300,400,100);
          iSetColor(255,255,0);
          iText(340,420,"Dear,",GLUT_BITMAP_TIMES_ROMAN_24);
          iText(400,420,str[index],GLUT_BITMAP_TIMES_ROMAN_24);
          iSetColor(0,0,0);
          iText(400,370,"Your score is :",GLUT_BITMAP_TIMES_ROMAN_24);
          iText(540,370,strscore,GLUT_BITMAP_TIMES_ROMAN_24);
          iText(400,340,"High Score is :",GLUT_BITMAP_TIMES_ROMAN_24);
          itoa(highscore,strhighscore,10);
          iText(540,340,strhighscore,GLUT_BITMAP_TIMES_ROMAN_24);
          if(score<=0)
          {
              iText(400,310,"You Lost the game",GLUT_BITMAP_TIMES_ROMAN_24);
          }
          else if(score<=100)
          {
              iText(400,310,"Not Satisfactory Well",GLUT_BITMAP_TIMES_ROMAN_24);
          }
          else if(score>100 && score<=150)
          {
              iText(400,310,"Quite good",GLUT_BITMAP_TIMES_ROMAN_24);
          }
          else if(score>150 && score<180)
          {
              iText(400,310,"Well done",GLUT_BITMAP_TIMES_ROMAN_24);
          }
          else if(score==180)
          {
              iText(400,310,"You are the real champ",GLUT_BITMAP_TIMES_ROMAN_24);
          }
          iSetColor(45,247,234);
          iFilledRectangle(700,100,200,50);
          iSetColor(0,0,0);
          iText(730,120,"TRY AGAIN",GLUT_BITMAP_TIMES_ROMAN_24);

          iSetColor(255,0,0);
          iText(100,20,"click anywhere to continue");


          // iText(200,200,"START",GLUT_BITMAP_TIMES_ROMAN_24);
          //iText(200,320,str,GLUT_BITMAP_TIMES_ROMAN_24);
          //iText(200,300,strscore,GLUT_BITMAP_TIMES_ROMAN_24);
    }

    else if(mode==5)
        {
            iClear();
            iSetColor(102,252,255);
            iFilledRectangle(0,0,1000,600);
			iSetColor(255,0,0);
			iFilledRectangle(200,300,600,50);
			iSetColor(255,255,0);
			iText(400,320,str[index],GLUT_BITMAP_TIMES_ROMAN_24);

		}
    else if(mode==-2)
    {
        iClear();
        iShowBMP(20,200,"bestscore.bmp");
        iSetColor(0,255,255);
        iFilledRectangle(400,200,400,200);
        itoa(highscore,strhighscore,10);
        iSetColor(0,0,0);
        iText(600,350,strhighscore,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(500,300,halloffame,GLUT_BITMAP_TIMES_ROMAN_24);
        iSetColor(0,255,255);
        iFilledRectangle(700,20,200,50);
        iSetColor(0,0,0);
        iText(750,35,"BACK",GLUT_BITMAP_TIMES_ROMAN_24);


    }



}

void colorchage()
{
    r1=rand()%255;
    g1=rand()%255;
    b1=rand()%255;
    r2=rand()%255;
    g2=rand()%255;
    b2=rand()%255;
    r3=rand()%255;
    g3=rand()%255;
    b3=rand()%255;
    r4=rand()%255;
    g4=rand()%255;
    b4=rand()%255;
}
void questioncopy()
{

    FILE *file;
    file=fopen(question_source[random_number],"r");

    if(file==NULL)
    {
        printf("File does not exist\n");
    }
    else
    {
        char line[10000];
        char *token;
        int i=0;
        while(fgets(line,10000,file))
        {
            token = strtok(line,"$");
            strcpy(mcq[i].level,token);
            token = strtok(NULL,"$");
            strcpy(mcq[i].question,token);
            token = strtok(NULL,"$");
            strcpy(mcq[i].opt1,token);
            token = strtok(NULL,"$");
            strcpy(mcq[i].opt2,token);
            token = strtok(NULL,"$");
            strcpy(mcq[i].opt3,token);
            token = strtok(NULL,"$");
            strcpy(mcq[i].opt4,token);
            token = strtok(NULL,"$");
            correct_answer[i]=token[0]-48;
            i++;
        }


        fclose(file);

        /*for(int j=0;j<9;j++)
        {
            printf("%s %s\n%s\n%s\n%s\n%s\n%d\n\n",mcq[j].level,mcq[j].question,mcq[j].opt1,mcq[j].opt2,mcq[j].opt3,mcq[j].opt4,correct_answer[j]);
        }*/
    }

}
void question_pass()
{
    if(question_number<9)

    {
        if(time_f - time_i > 10)
        {
            question_number++;
            load=0;
            loadcolor=30;
            time_i = time(NULL);

            time_f = time(NULL);
        }

        //question_number++;
    }
    if(question_number==9)
    {
        mode=5;
        question_number=10;
    }

}
void modechange()
   {

       mode=3;
       if(option==correct_answer[question_number])
       {
           state=1;
           if(question_number>=0 && question_number<=2)
           {
               score=score+10;
           }
           else if(question_number>=3 && question_number<=5)
           {
               score=score+20;
           }
           else if(question_number>=6 && question_number<=8)
           {
               score=score+30;
           }
           itoa(score,strscore,10);

       }
       else if(option!=correct_answer[question_number])
       {
           state=0;
           score=score-10;
           itoa(score,strscore,10);
       }
   }
/*

/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
	*/
void gamestorage()
{
    FILE *fp=fopen("gamestorage.txt","r");
    fscanf(fp,"%d",&highscore);
    fgets(halloffame,100,fp);
    fclose(fp);
    if(score>=highscore)
    {
        highscore=score;
        strcpy(halloffame,str[index]);
        FILE *update=fopen("gamestorage.txt","w");
        fprintf(update,"%d %s",score,str[index]);
        fclose(update);
    }
}
void iMouseMove(int mx, int my) {

}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
	*/
void iMouse(int button, int state, int mx, int my) {
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
        {
            if(mode==0)
            {
                 if((mx>0 && mx<480) && (my<250 && my>140))
                 {

                  srand(time(NULL));
                  random_number=rand()%3;
                  check=rand();
                  questioncopy();
                  mode=2;
                  time_i=time(NULL);

                  iResumeTimer(t1);
                  iResumeTimer(t2);

                 }
                 else if((mx>480 && mx<1000) && (my<250 && my>140))
                 {
                      mode=1;


                 }
                 else if((mx>0 && mx<480) && (my<140 && my>50))
                 {
                      mode=-2;
                      gamestorage();
                 }

                 else if((mx>480 && mx<1000) && (my<140) && my>50)
                 {
                      exit(0);
                 }
                 else if((mx>800 && mx<1000)&&(my<50))
                 {
                     mode=-1;
                 }
            }
            else if(mode==1)
            {
                if((mx>730 && mx<900) && (my>50  && my<100))
                {
                    mode=0;

                }
            }
            else if(mode==2)
            {


                 if((mx>0 && mx<490) && (my>210 && my<320))
                 {
                      option=1;
                      modechange();

                 }
                 else if((mx>490 && mx<1000) && (my>210 && my<320))
                 {
                      option=2;
                      modechange();
                 }
                  else if((mx>0 && mx<490) && (my>100 && my<210))
                 {
                      option=3;
                      modechange();
                 }
                  else if((mx>490 && mx<1000) && (my>100 && my<210))
                 {
                      option=4;
                      modechange();
                 }
            }
            else if(mode==-1)
            {
                  if((mx>800 && mx <950) && (my>50 && my <100))
                  {
                      mode=0;
                  }
            }
            else if(mode==3)
		    {
                if(question_number<9)
                {
                   question_number++;
                   load=0;
                   loadcolor=30;
                   time_i = time(NULL);
                   time_f = time(NULL);

                   if(question_number!=9) mode=2;

                }
                /*if(question_number<10)
                {
                    time_i = time(NULL);
                    mode=2;
                }*/
                else if(question_number==9) mode=5;
              }
            else if(mode==4)
            {
                if((mx>700 && mx<900) && (my>100 && my<150))
                {

                   //gamestorage();


                    srand(time(NULL));
                    random_number=rand()%3;
                    check=rand();
                    questioncopy();


                     mode=2;
                     score=0;
                     load=0;
                     question_number=0;
                     time_i=time(NULL);
                     index++;


                }
                else
                {
                     //gamestorage();
                     mode=0;
                     score=0;
                     load=0;
                     question_number=0;
                     iPauseTimer(t1);
                     iPauseTimer(t2);
                     index++;


                }

            }
            else if(mode==-2)
            {
                if((mx>700 && mx<900) && (my>20 && my<70))
                {
                    mode=0;
                }
            }



        }

	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
        {
             //if(mode==-2) mode=0;




	    }

}


	/*function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
	*/
void iKeyboard(unsigned char key) {


    if(mode==2)
    {
        if(key=='a')
        {
            option=1;
            modechange();
        }
        else if(key=='b')
        {
            option=2;
            modechange();
        }
            if(key=='c')
        {
            option=3;
            modechange();
        }
        if(key=='d')
        {
            option=4;
            modechange();
        }
    }

    if(mode!=5)
    {
           if(key=='s')
        {

        music=music*(-1);
        if(music==1)
        {
            PlaySound("guts.wav",NULL,SND_ASYNC | SND_LOOP);

        }
        else if(music==-1)
         {
             PlaySound(0,0,0);
         }

         }
    }
    else if(mode==5)
    {
        if(key == '\r')
		{
			//strcpy(str2, str[index]);
			//printf("%s\n", str2);
			//for(int k  = 0; k < len; k++)
            //str[k] = 0;
			len = 0;
			gamestorage();
			mode=4;
		}
         else
		{
			str[index][len] = key;
			len++;
		}
    }
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
	*/
void iSpecialKeyboard(unsigned char key) {

	if (key == GLUT_KEY_END) {
		exit(0);
	}
	//place your codes for other keys here
}

//Author : NILOY KUMAR MONDAL , CSE-21, BUET
//LAST UPDATED:01.03.2023
//Acknowledgment : Each & every emoji,picture,sound template are taken from google
void loadchange()
{
    load+=11;
    loadcolor+=2;
}
void co_ordinatechange()
{
    bcx+=dx;
    bcy+=dy;
    if(bcx<=0 || bcx>=800) dx*=-1;
    if(bcy<=0 || bcy>400) dy*=-1;
}

int main() {
    time_i = time(NULL);
    time_f = time(NULL);
    //questioncopy();
    iSetTimer(30,co_ordinatechange);
    iSetTimer(500,colorchage);



    t1=iSetTimer(100,question_pass);
    t2=iSetTimer(100,loadchange);

    iPauseTimer(t1);
    iPauseTimer(t2);

    //PlaySound("guts.wav",NULL,SND_ASYNC | SND_LOOP);


	iInitialize(width,height,"Rapid Fire");

	return 0;
}

